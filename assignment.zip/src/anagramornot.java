
public class anagramornot {

}
